<link rel="stylesheet" type="text/css" href="./resource/css/main.css">
<link rel="stylesheet" type="text/css" href="./resource/css/carousel.css">
<link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css">
<div style="position: fixed; background: #fff; width: 100%; z-index: 9999;">
<div id='wrapper'>
    <header>
        <div id='logoArea'>
            <img src='./resource/img/logo.png'>
        </div>
        <nav>
            <a href='#'>Home</a>
            <a href='#about'>About</a>
            <a href='#portfolio'>Portfolio</a>
            <a href='#contact'>Contact</a>
        </nav>
        <div id='superBtn'>
            <button>Hire Us</button>
        </div>
    </header>
</div>
</div>
