<footer>
    <div id="wrapper">
        <div class='footerFlex'>
            <div id="flex" style="flex: 1;">
                <a href='#'><i class="fa-brands fa-facebook"></i></a>
                <a href='#'><i class="fa-brands fa-x-twitter"></i></a>
                <a href='#'><i class="fa-brands fa-linkedin"></i></a>
            </div>
            <div id="flex" style="flex: 1;">
                <center><img src='./resource/img/logo.png' style='filter: brightness(0) invert(1);' width='140px'></center>
            </div>
            <div id="flex" style="flex: 1;">
                <p>contact@domain.com</p>
                <p>+91 88888 55555</p>
            </div>
        </div>
    </div>
</footer>
<script src="https://kit.fontawesome.com/612ce50f4d.js" crossorigin="anonymous"></script>